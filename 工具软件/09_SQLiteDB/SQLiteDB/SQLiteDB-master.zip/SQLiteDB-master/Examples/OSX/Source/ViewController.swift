//
//  ViewController.swift
//  SQLiteDB-OSX
//
//  Created by Fahim Farook on 9/26/14.
//  Copyright (c) 2014 RookSoft Pte. Ltd. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

	override func viewDidLoad() {
		super.viewDidLoad()

		// Do any additional setup after loading the view.
	}

	override var representedObject: Any? {
		didSet {
		// Update the view, if already loaded.
		}
	}


}

